﻿namespace Cartoon_Coursework
{


    partial class Database1DataSet
    {
    }
}
